param(
  [string]$WorkspaceRoot = "D:\AI\omniauto",
  [bool]$ApplyGlobalRecorderModules = $true
)

$ErrorActionPreference = "Stop"
$pkgRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$payloadTenantRoot = Join-Path $pkgRoot "payload\runtime\tenants\test02"
if (!(Test-Path $payloadTenantRoot)) {
  throw "Payload not found: $payloadTenantRoot"
}

$targetAppRoot = Join-Path $WorkspaceRoot "runtime\apps\wechat_ai_customer_service"
$targetTenantRoot = Join-Path $targetAppRoot "tenants\test02"
$backupRoot = Join-Path $targetAppRoot "migration_import_backups"
New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
if (Test-Path $targetTenantRoot) {
  $backupZip = Join-Path $backupRoot "test02_before_import_$ts.zip"
  Compress-Archive -Path (Join-Path $targetTenantRoot "*") -DestinationPath $backupZip -Force
  Write-Host "Backed up existing tenant folder to: $backupZip"
} else {
  New-Item -ItemType Directory -Force -Path $targetTenantRoot | Out-Null
}

Copy-Item -Path (Join-Path $payloadTenantRoot "*") -Destination $targetTenantRoot -Recurse -Force
Write-Host "Imported payload to: $targetTenantRoot"

if ($ApplyGlobalRecorderModules) {
  $optRoot = Join-Path $pkgRoot "optional_reference\global\recorder_modules"
  $srcBindings = Join-Path $optRoot "module_bindings.json"
  $srcRegistry = Join-Path $optRoot "module_registry.json"
  $dstBindings = Join-Path $targetAppRoot "admin\recorder_modules\module_bindings.json"
  $dstRegistry = Join-Path $targetAppRoot "admin\recorder_modules\module_registry.json"

  $bindingsBackup = Join-Path $backupRoot "module_bindings_before_import_$ts.json"
  $registryBackup = Join-Path $backupRoot "module_registry_before_import_$ts.json"

  function Read-JsonArray([string]$path) {
    if (!(Test-Path $path)) { return @() }
    $raw = Get-Content -LiteralPath $path -Raw -Encoding utf8
    if ([string]::IsNullOrWhiteSpace($raw)) { return @() }
    $obj = ConvertFrom-Json -InputObject $raw
    if ($obj -is [System.Array]) { return @($obj) }
    return @()
  }

  if ((Test-Path $srcBindings) -and (Test-Path $srcRegistry)) {
    if (Test-Path $dstBindings) { Copy-Item -LiteralPath $dstBindings -Destination $bindingsBackup -Force }
    if (Test-Path $dstRegistry) { Copy-Item -LiteralPath $dstRegistry -Destination $registryBackup -Force }

    $targetBindings = Read-JsonArray $dstBindings
    $sourceBindings = Read-JsonArray $srcBindings
    $sourceTest02 = @($sourceBindings | Where-Object { $_.scope_type -eq 'tenant' -and $_.scope_id -eq 'test02' })
    if ($sourceTest02.Count -gt 0) {
      $filtered = @($targetBindings | Where-Object { -not ($_.scope_type -eq 'tenant' -and $_.scope_id -eq 'test02') })
      $mergedBindings = @($filtered + $sourceTest02)
      $bindingsJson = $mergedBindings | ConvertTo-Json -Depth 20
      Set-Content -LiteralPath $dstBindings -Value $bindingsJson -Encoding utf8
      Write-Host "Merged tenant test02 bindings into: $dstBindings"
    } else {
      Write-Host "No tenant-scoped test02 binding found in source package; skipped binding merge."
    }

    $targetRegistry = Read-JsonArray $dstRegistry
    $sourceRegistry = Read-JsonArray $srcRegistry
    $sourceModule = @($sourceRegistry | Where-Object { $_.module_key -eq 'order_sheet_lab_v1' -or $_.module_key -eq 'raw_message_log_v1' })
    if ($sourceModule.Count -gt 0) {
      $targetFiltered = @($targetRegistry | Where-Object { $_.module_key -ne 'order_sheet_lab_v1' -and $_.module_key -ne 'raw_message_log_v1' })
      $mergedRegistry = @($targetFiltered + $sourceModule)
      $registryJson = $mergedRegistry | ConvertTo-Json -Depth 50
      Set-Content -LiteralPath $dstRegistry -Value $registryJson -Encoding utf8
      Write-Host "Merged recorder module registry entries into: $dstRegistry"
    } else {
      Write-Host "No target modules found in source package; skipped registry merge."
    }
  } else {
    Write-Host "Optional global module files not found in package; skipped global merge."
  }
}

Write-Host "Done. Please restart admin backend + worker processes."
