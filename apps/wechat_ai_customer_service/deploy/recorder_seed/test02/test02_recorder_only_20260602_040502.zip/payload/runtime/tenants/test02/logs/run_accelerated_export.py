import sys
sys.path.insert(0, r'D:\AI\omniauto')
from apps.wechat_ai_customer_service.admin_backend.services.recorder_export_run_service import RecorderExportRunService
import json
result = RecorderExportRunService(tenant_id='test02').process_run('recorder_export_run_5b6dde333263b6176d77')
print(json.dumps({'ok': result.get('ok'), 'status': (result.get('run') or {}).get('status'), 'error': result.get('error')}, ensure_ascii=False))
